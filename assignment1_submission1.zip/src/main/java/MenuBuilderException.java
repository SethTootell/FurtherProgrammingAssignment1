public class MenuBuilderException extends RuntimeException {
    public MenuBuilderException(String message) {
        super(message);
    }
}
